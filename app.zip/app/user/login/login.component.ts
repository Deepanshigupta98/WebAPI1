import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styles: []
  // styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
formModel = {
  User_Name: '',
  Pass_word: ''
}
  constructor() { }

  ngOnInit(): void {
  }

}
